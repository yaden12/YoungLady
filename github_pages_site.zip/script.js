const correctPassword = "1234"; // Замени на свой пароль

function checkPassword() {
    const input = document.getElementById("passwordInput").value;
    if (input === correctPassword) {
        document.getElementById("login").style.display = "none";
        document.getElementById("content").style.display = "block";
    } else {
        document.getElementById("error").classList.remove("hidden");
    }
}
